<?php
class HomeModel{
    public function __construct()
    {
        
    }
}

?>